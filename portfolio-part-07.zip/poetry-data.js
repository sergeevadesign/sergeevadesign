export const book = {
  "title": "Абрыс знікаючага",
  "kind": "Сборник стихов",
  "width": 1682,
  "height": 2400,
  "pages": [
    {
      "sourceNumber": 1,
      "src": "assets/poetry/01.webp",
      "full": "assets/poetry/01-full.webp",
      "alt": "Передняя обложка сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 2,
      "src": "assets/poetry/02.webp",
      "full": "assets/poetry/02-full.webp",
      "alt": "Страница 2 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 3,
      "src": "assets/poetry/03.webp",
      "full": "assets/poetry/03-full.webp",
      "alt": "Страница 3 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 4,
      "src": "assets/poetry/04.webp",
      "full": "assets/poetry/04-full.webp",
      "alt": "Страница 4 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 5,
      "src": "assets/poetry/05.webp",
      "full": "assets/poetry/05-full.webp",
      "alt": "Страница 5 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 6,
      "src": "assets/poetry/06.webp",
      "full": "assets/poetry/06-full.webp",
      "alt": "Страница 6 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 7,
      "src": "assets/poetry/07.webp",
      "full": "assets/poetry/07-full.webp",
      "alt": "Страница 7 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 8,
      "src": "assets/poetry/08.webp",
      "full": "assets/poetry/08-full.webp",
      "alt": "Страница 8 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 9,
      "src": "assets/poetry/09.webp",
      "full": "assets/poetry/09-full.webp",
      "alt": "Страница 9 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 10,
      "src": "assets/poetry/10.webp",
      "full": "assets/poetry/10-full.webp",
      "alt": "Страница 10 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 11,
      "src": "assets/poetry/11.webp",
      "full": "assets/poetry/11-full.webp",
      "alt": "Страница 11 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 12,
      "src": "assets/poetry/12.webp",
      "full": "assets/poetry/12-full.webp",
      "alt": "Страница 12 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 13,
      "src": "assets/poetry/13.webp",
      "full": "assets/poetry/13-full.webp",
      "alt": "Страница 13 сборника «Абрыс знікаючага»"
    },
    {
      "sourceNumber": 14,
      "src": "assets/poetry/14.webp",
      "full": "assets/poetry/14-full.webp",
      "alt": "Задняя обложка сборника «Абрыс знікаючага»"
    }
  ]
};
