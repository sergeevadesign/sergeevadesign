export const book = {
  "title": "Мастацтва",
  "kind": "Редизайн журнала",
  "width": 1430,
  "height": 2048,
  "pages": [
    {
      "sourceFile": "proj-51.jpg",
      "side": "cover",
      "src": "assets/mastactva/01.webp",
      "full": "assets/mastactva/01-full.jpg",
      "width": 1430,
      "height": 2048,
      "alt": "Передняя обложка журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-43.jpg",
      "side": "left",
      "src": "assets/mastactva/02.webp",
      "full": "assets/mastactva/02-full.webp",
      "width": 1024,
      "height": 1466,
      "alt": "Левая страница разворота 1 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-43.jpg",
      "side": "right",
      "src": "assets/mastactva/03.webp",
      "full": "assets/mastactva/03-full.webp",
      "width": 1024,
      "height": 1466,
      "alt": "Правая страница разворота 1 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-44.jpg",
      "side": "left",
      "src": "assets/mastactva/04.webp",
      "full": "assets/mastactva/04-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Левая страница разворота 2 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-44.jpg",
      "side": "right",
      "src": "assets/mastactva/05.webp",
      "full": "assets/mastactva/05-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Правая страница разворота 2 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-45.jpg",
      "side": "left",
      "src": "assets/mastactva/06.webp",
      "full": "assets/mastactva/06-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Левая страница разворота 3 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-45.jpg",
      "side": "right",
      "src": "assets/mastactva/07.webp",
      "full": "assets/mastactva/07-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Правая страница разворота 3 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-46.jpg",
      "side": "left",
      "src": "assets/mastactva/08.webp",
      "full": "assets/mastactva/08-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Левая страница разворота 4 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-46.jpg",
      "side": "right",
      "src": "assets/mastactva/09.webp",
      "full": "assets/mastactva/09-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Правая страница разворота 4 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-47.jpg",
      "side": "left",
      "src": "assets/mastactva/10.webp",
      "full": "assets/mastactva/10-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Левая страница разворота 5 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-47.jpg",
      "side": "right",
      "src": "assets/mastactva/11.webp",
      "full": "assets/mastactva/11-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Правая страница разворота 5 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-48.jpg",
      "side": "left",
      "src": "assets/mastactva/12.webp",
      "full": "assets/mastactva/12-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Левая страница разворота 6 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-48.jpg",
      "side": "right",
      "src": "assets/mastactva/13.webp",
      "full": "assets/mastactva/13-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Правая страница разворота 6 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-49.jpg",
      "side": "left",
      "src": "assets/mastactva/14.webp",
      "full": "assets/mastactva/14-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Левая страница разворота 7 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-49.jpg",
      "side": "right",
      "src": "assets/mastactva/15.webp",
      "full": "assets/mastactva/15-full.webp",
      "width": 1024,
      "height": 1467,
      "alt": "Правая страница разворота 7 журнала «Мастацтва»"
    },
    {
      "sourceFile": "proj-50.jpg",
      "side": "cover",
      "src": "assets/mastactva/16.webp",
      "full": "assets/mastactva/16-full.jpg",
      "width": 1335,
      "height": 1913,
      "alt": "Задняя обложка журнала «Мастацтва»"
    }
  ]
};
