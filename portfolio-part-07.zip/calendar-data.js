export const calendar = {
  "title": "Календарь-каталог парфюма",
  "year": 2026,
  "width": 1131,
  "height": 1600,
  "pages": [
    {
      "src": "assets/perfume-calendar/01.webp",
      "full": "assets/perfume-calendar/01-full.webp",
      "type": "cover",
      "month": null,
      "label": "Обложка",
      "alt": "Обложка календаря «Календарь-каталог парфюма 2026»"
    },
    {
      "src": "assets/perfume-calendar/02.webp",
      "full": "assets/perfume-calendar/02-full.webp",
      "type": "vellum",
      "month": 1,
      "label": "Калька / Январь",
      "alt": "Лист кальки со стихотворением, январь"
    },
    {
      "src": "assets/perfume-calendar/03.webp",
      "full": "assets/perfume-calendar/03-full.webp",
      "type": "paper",
      "month": 1,
      "label": "Январь 2026",
      "alt": "Календарь, январь 2026"
    },
    {
      "src": "assets/perfume-calendar/04.webp",
      "full": "assets/perfume-calendar/04-full.webp",
      "type": "vellum",
      "month": 3,
      "label": "Калька / Март",
      "alt": "Лист кальки со стихотворением, март"
    },
    {
      "src": "assets/perfume-calendar/05.webp",
      "full": "assets/perfume-calendar/05-full.webp",
      "type": "paper",
      "month": 3,
      "label": "Март 2026",
      "alt": "Календарь, март 2026"
    },
    {
      "src": "assets/perfume-calendar/06.webp",
      "full": "assets/perfume-calendar/06-full.webp",
      "type": "vellum",
      "month": 5,
      "label": "Калька / Май",
      "alt": "Лист кальки со стихотворением, май"
    },
    {
      "src": "assets/perfume-calendar/07.webp",
      "full": "assets/perfume-calendar/07-full.webp",
      "type": "paper",
      "month": 5,
      "label": "Май 2026",
      "alt": "Календарь, май 2026"
    },
    {
      "src": "assets/perfume-calendar/08.webp",
      "full": "assets/perfume-calendar/08-full.webp",
      "type": "vellum",
      "month": 7,
      "label": "Калька / Июль",
      "alt": "Лист кальки со стихотворением, июль"
    },
    {
      "src": "assets/perfume-calendar/09.webp",
      "full": "assets/perfume-calendar/09-full.webp",
      "type": "paper",
      "month": 7,
      "label": "Июль 2026",
      "alt": "Календарь, июль 2026"
    },
    {
      "src": "assets/perfume-calendar/10.webp",
      "full": "assets/perfume-calendar/10-full.webp",
      "type": "vellum",
      "month": 9,
      "label": "Калька / Сентябрь",
      "alt": "Лист кальки со стихотворением, сентябрь"
    },
    {
      "src": "assets/perfume-calendar/11.webp",
      "full": "assets/perfume-calendar/11-full.webp",
      "type": "paper",
      "month": 9,
      "label": "Сентябрь 2026",
      "alt": "Календарь, сентябрь 2026"
    },
    {
      "src": "assets/perfume-calendar/12.webp",
      "full": "assets/perfume-calendar/12-full.webp",
      "type": "vellum",
      "month": 2,
      "label": "Калька / Февраль",
      "alt": "Лист кальки со стихотворением, февраль"
    },
    {
      "src": "assets/perfume-calendar/13.webp",
      "full": "assets/perfume-calendar/13-full.webp",
      "type": "paper",
      "month": 2,
      "label": "Февраль 2026",
      "alt": "Календарь, февраль 2026"
    },
    {
      "src": "assets/perfume-calendar/14.webp",
      "full": "assets/perfume-calendar/14-full.webp",
      "type": "vellum",
      "month": 4,
      "label": "Калька / Апрель",
      "alt": "Лист кальки со стихотворением, апрель"
    },
    {
      "src": "assets/perfume-calendar/15.webp",
      "full": "assets/perfume-calendar/15-full.webp",
      "type": "paper",
      "month": 4,
      "label": "Апрель 2026",
      "alt": "Календарь, апрель 2026"
    },
    {
      "src": "assets/perfume-calendar/16.webp",
      "full": "assets/perfume-calendar/16-full.webp",
      "type": "vellum",
      "month": 6,
      "label": "Калька / Июнь",
      "alt": "Лист кальки со стихотворением, июнь"
    },
    {
      "src": "assets/perfume-calendar/17.webp",
      "full": "assets/perfume-calendar/17-full.webp",
      "type": "paper",
      "month": 6,
      "label": "Июнь 2026",
      "alt": "Календарь, июнь 2026"
    },
    {
      "src": "assets/perfume-calendar/18.webp",
      "full": "assets/perfume-calendar/18-full.webp",
      "type": "vellum",
      "month": 8,
      "label": "Калька / Август",
      "alt": "Лист кальки со стихотворением, август"
    },
    {
      "src": "assets/perfume-calendar/19.webp",
      "full": "assets/perfume-calendar/19-full.webp",
      "type": "paper",
      "month": 8,
      "label": "Август 2026",
      "alt": "Календарь, август 2026"
    },
    {
      "src": "assets/perfume-calendar/20.webp",
      "full": "assets/perfume-calendar/20-full.webp",
      "type": "vellum",
      "month": 10,
      "label": "Калька / Октябрь",
      "alt": "Лист кальки со стихотворением, октябрь"
    },
    {
      "src": "assets/perfume-calendar/21.webp",
      "full": "assets/perfume-calendar/21-full.webp",
      "type": "paper",
      "month": 10,
      "label": "Октябрь 2026",
      "alt": "Календарь, октябрь 2026"
    },
    {
      "src": "assets/perfume-calendar/22.webp",
      "full": "assets/perfume-calendar/22-full.webp",
      "type": "cover",
      "month": null,
      "label": "Задняя обложка",
      "alt": "Задняя обложка календаря"
    }
  ]
};
