export function clampLeaf(index, total) {
  return Math.max(0, Math.min(total - 1, index));
}
// A translucent sheet must reveal the next opaque sheet, including any intervening vellum.
export function calendarStack(index, pages) {
  const result = [];
  for (let i = clampLeaf(index, pages.length); i < pages.length; i++) {
    result.push(i);
    if (pages[i].type !== 'vellum') break;
  }
  return result;
}
export function calendarCurl(progress, height, count = 20) {
  const step = height / count;
  const bend = Math.sin(Math.PI * progress) * .5;
  const strips = [];
  let y = 0, z = 0;
  for (let i = 0; i < count; i++) {
    const angle = Math.PI * progress - bend * (i / (count - 1) - .3);
    strips.push({ y, z, angle });
    y += Math.cos(angle) * step;
    z += Math.sin(angle) * step;
  }
  return strips;
}
