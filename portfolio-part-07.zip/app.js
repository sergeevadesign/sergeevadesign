const projects = {
  editorial: { category: 'Editorial Design', format: 'Обложка и последовательность разворотов' },
  calendar: { category: 'Calendar Design', format: 'Система, страницы и печатный объект' },
  posters: { category: 'Posters & Visual Identity', format: 'Плакат или плакатная серия' },
  identity: { category: 'Posters & Visual Identity', format: 'Логотип, фирменные элементы и применение' },
  presentation: { category: 'Presentation Design', format: 'Последовательность слайдов и визуальная система' }
};
const dialog = document.querySelector('#project-dialog');
let trigger;
document.querySelectorAll('[data-project]').forEach(button => {
  button.addEventListener('click', () => {
    trigger = button;
    const project = projects[button.dataset.project];
    document.querySelector('#dialog-category').textContent = project.category;
    dialog.querySelector('.dialog-media span:first-child').textContent = project.format;
    dialog.showModal();
    document.body.style.overflow = 'hidden';
  });
});
dialog.querySelector('.dialog-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => {
  const r = dialog.getBoundingClientRect();
  if (event.target === dialog && (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom)) dialog.close();
});
dialog.addEventListener('close', () => { document.body.style.overflow = ''; trigger?.focus({ preventScroll: true }); });
const currentPage = document.body.dataset.page;
document.querySelectorAll('.floating-nav a').forEach(link => {
  const active = link.getAttribute('href') === currentPage + '.html';
  link.classList.toggle('active', active);
  if (active) link.setAttribute('aria-current', 'page');
});
if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('reveal'); observer.unobserve(entry.target); } }), { threshold: 0.08 });
  document.querySelectorAll('.category-heading,.awards').forEach(element => observer.observe(element));
}
