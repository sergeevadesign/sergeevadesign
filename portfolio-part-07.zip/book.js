import { spreadForPage, pagesForSpread, firstPageOfSpread, nextPage } from './book-state.mjs';
const publications = {viartanne: './booklet-data.js', poetry: './poetry-data.js', mastactva: './mastactva-data.js'};
const dataSource = publications[document.body.dataset.publication] || './book-data.js';
const { book } = await import(dataSource);

const reader = document.querySelector('.book-reader');
const stage = reader.querySelector('.reader-stage');
reader.style.setProperty('--page-ratio', String(book.width / book.height));
reader.style.setProperty('--spread-ratio', String(2 * book.width / book.height));
const object = reader.querySelector('.book-object');
const groundShadow = document.createElement('div');
groundShadow.className = 'book-ground-shadow';
groundShadow.setAttribute('aria-hidden', 'true');
stage.prepend(groundShadow);
const singleImage = reader.querySelector('.single-page img');
const status = reader.querySelector('.reader-status');
const error = reader.querySelector('.reader-error');
const slider = reader.querySelector('input[type="range"]');
const previous = [...reader.querySelectorAll('[data-turn="-1"]')];
const next = [...reader.querySelectorAll('[data-turn="1"]')];
const zoom = document.querySelector('#page-zoom');
const mobile = matchMedia('(max-width: 700px)');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const cache = new Map();
const sheets = [];
let page = 0;
let single = mobile.matches;
let busy = false;
let resizePending = false;
let zoomTrigger;

function preload(index) {
  if (index === null || index < 0 || index >= book.pages.length) return Promise.resolve();
  if (cache.has(index)) return cache.get(index);
  const promise = new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => { cache.delete(index); reject(new Error('image')); };
    image.src = book.pages[index].src;
  });
  cache.set(index, promise);
  return promise;
}

function visible(index = page, one = single) {
  return one ? [index] : pagesForSpread(spreadForPage(index, book.pages.length), book.pages.length).filter(n => n !== null);
}

function shift(spread) {
  return spread === 0 ? -25 : spread === book.pages.length / 2 ? 25 : 0;
}

function updateShadow(spread, nextSpread = spread, progress = 0) {
  const widthAt = value => value === 0 || value === book.pages.length / 2 ? 50 : 100;
  const width = widthAt(spread) + (widthAt(nextSpread) - widthAt(spread)) * progress;
  groundShadow.style.width = `${width}%`;
  groundShadow.style.left = `${(100 - width) / 2}%`;
}

function syncControls() {
  const atStart = single ? page === 0 : spreadForPage(page, book.pages.length) === 0;
  const atEnd = single ? page === book.pages.length - 1 : spreadForPage(page, book.pages.length) === book.pages.length / 2;
  previous.forEach(button => button.disabled = busy || atStart);
  next.forEach(button => button.disabled = busy || atEnd);
  slider.disabled = busy;
  reader.querySelector('.reader-zoom').disabled = busy;
  reader.setAttribute('aria-busy', String(busy));
}

function render() {
  const spread = spreadForPage(page, book.pages.length);
  updateShadow(spread);
  stage.classList.toggle('is-single', single);
  object.style.transform = `translateX(${shift(spread)}%)`;
  sheets.forEach((sheet, i) => {
    sheet.classList.toggle('turned', i < spread);
    sheet.style.zIndex = i < spread ? i + 1 : sheets.length - i;
    for (let side = 0; side < 2; side++) {
      const index = i * 2 + side;
      const image = sheet.querySelectorAll('img')[side];
      if (Math.abs(i - spread) <= 2 && cache.has(index)) image.src = book.pages[index].src;
    }
  });
  singleImage.src = book.pages[page].src;
  singleImage.alt = book.pages[page].alt;
  const shown = visible();
  status.textContent = page === 0 ? 'Передняя обложка' : page === book.pages.length - 1 ? 'Задняя обложка' : shown.length > 1 ? `Страницы ${shown[0] + 1}–${shown[1] + 1}` : `Страница ${page + 1} из ${book.pages.length}`;
  slider.value = page + 1;
  slider.setAttribute('aria-valuetext', status.textContent);
  syncControls();
  const neighbors = new Set([...shown, ...visible(nextPage(page, 1, book.pages.length, single)), ...visible(nextPage(page, -1, book.pages.length, single))]);
  neighbors.forEach(index => preload(index).then(() => {
    if (!single) {
      const image = sheets[Math.floor(index / 2)].querySelectorAll('img')[index % 2];
      image.src = book.pages[index].src;
    }
  }).catch(() => {}));
}

for (let i = 0; i < book.pages.length / 2; i++) {
  const sheet = document.createElement('div');
  sheet.className = 'book-leaf';
  for (let side = 0; side < 2; side++) {
    const face = document.createElement('div');
    face.className = `book-face ${side ? 'back' : 'front'}`;
    const image = document.createElement('img');
    image.alt = '';
    image.draggable = false;
    face.append(image);
    sheet.append(face);
  }
  sheets.push(sheet);
  object.append(sheet);
}

function animateCurl(from, to) {
  const fromSpread = spreadForPage(from, book.pages.length);
  const toSpread = spreadForPage(to, book.pages.length);
  const forward = toSpread > fromSpread;
  const sheetIndex = forward ? fromSpread : fromSpread - 1;
  const layer = document.createElement('div');
  layer.className = 'curl-layer';
  const width = stage.clientWidth / 2;
  const height = stage.clientHeight;
  const count = 18;
  const step = width / count;
  const strips = [];
  for (let i = 0; i < count; i++) {
    const strip = document.createElement('div');
    strip.className = 'curl-strip';
    strip.style.width = `${step + .45}px`;
    const shades = [];
    for (let side = 0; side < 2; side++) {
      const face = document.createElement('div');
      face.className = `curl-face ${side ? 'back' : 'front'}`;
      face.style.backgroundImage = `url("${book.pages[sheetIndex * 2 + side].src}")`;
      face.style.backgroundSize = `${width}px ${height}px`;
      face.style.backgroundPosition = `${-(side ? count - 1 - i : i) * step}px 0`;
      const shade = document.createElement('div');
      shade.className = 'curl-shade';
      face.append(shade);
      shades.push(shade);
      strip.append(face);
    }
    strips.push({ strip, shades });
    layer.append(strip);
  }
  sheets[sheetIndex].classList.add('turning');
  object.append(layer);
  return new Promise(resolve => {
    let start;
    function frame(now) {
      start ??= now;
      const t = Math.min(1, (now - start) / 880);
      const eased = t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      const p = forward ? eased : 1 - eased;
      const bend = Math.sin(Math.PI * p) * .6;
      const dim = Math.sin(Math.PI * p) * .045;
      let x = 0, z = 0;
      strips.forEach(({ strip, shades }, i) => {
        const angle = -Math.PI * p + bend * (i / (count - 1) - .4);
        strip.style.transform = `translate3d(${x}px,0,${z}px) rotateY(${angle}rad)`;
        shades[0].style.opacity = dim;
        shades[1].style.opacity = dim;
        x += Math.cos(angle) * step;
        z -= Math.sin(angle) * step;
      });
      object.style.transform = `translateX(${shift(fromSpread) + (shift(toSpread) - shift(fromSpread)) * eased}%)`;
      updateShadow(fromSpread, toSpread, eased);
      if (t < 1) requestAnimationFrame(frame);
      else {
        page = to;
        render();
        sheets[sheetIndex].classList.remove('turning');
        layer.remove();
        resolve();
      }
    }
    requestAnimationFrame(frame);
  });
}

async function go(target, animate = true) {
  if (busy) return;
  target = Math.max(0, Math.min(book.pages.length - 1, target));
  if (!single) target = firstPageOfSpread(spreadForPage(target, book.pages.length), book.pages.length);
  if (target === page) return;
  busy = true;
  error.textContent = '';
  syncControls();
  try {
    const needed = new Set([...visible(), ...visible(target)]);
    if (!single && Math.abs(spreadForPage(target, book.pages.length) - spreadForPage(page, book.pages.length)) === 1) {
      const sheet = Math.min(spreadForPage(page, book.pages.length), spreadForPage(target, book.pages.length));
      needed.add(sheet * 2);
      needed.add(sheet * 2 + 1);
    }
    await Promise.all([...needed].map(preload));
    if (animate && !reduced.matches && !single && Math.abs(spreadForPage(target, book.pages.length) - spreadForPage(page, book.pages.length)) === 1) {
      await animateCurl(page, target);
    } else if (animate && !reduced.matches && single && typeof singleImage.animate === 'function') {
      const direction = target > page ? 1 : -1;
      await singleImage.animate([{ opacity: 1, transform: 'translateX(0)' }, { opacity: 0, transform: `translateX(${-direction * 16}px)` }], { duration: 150, fill: 'forwards' }).finished;
      singleImage.getAnimations().forEach(animation => animation.cancel());
      page = target;
      render();
      await singleImage.animate([{ opacity: 0, transform: `translateX(${direction * 16}px)` }, { opacity: 1, transform: 'translateX(0)' }], { duration: 180 }).finished;
    } else {
      page = target;
      render();
    }
  } catch (_) {
    error.textContent = 'Не удалось загрузить страницу. Проверьте соединение и попробуйте ещё раз.';
  } finally {
    busy = false;
    if (resizePending) { resizePending = false; resize(); } else render();
  }
}

reader.querySelectorAll('[data-turn]').forEach(button => button.addEventListener('click', () => go(nextPage(page, Number(button.dataset.turn), book.pages.length, single))));
slider.max = book.pages.length;
slider.addEventListener('change', () => go(Number(slider.value) - 1, false));
document.addEventListener('keydown', event => {
  if (zoom.open || ['INPUT', 'TEXTAREA', 'SELECT'].includes(event.target.tagName)) return;
  if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
    event.preventDefault();
    go(nextPage(page, event.key === 'ArrowRight' ? 1 : -1, book.pages.length, single));
  }
  if (event.key === 'Home') { event.preventDefault(); go(0, false); }
  if (event.key === 'End') { event.preventDefault(); go(book.pages.length - 1, false); }
  if (event.key === 'Escape') {
    document.body.classList.remove('reader-expanded');
    fullscreen.textContent = 'На весь экран ↗';
  }
});
let pointer;
let suppressClickUntil = 0;
stage.addEventListener('click', event => {
  if (performance.now() < suppressClickUntil) {
    event.preventDefault();
    event.stopImmediatePropagation();
  }
}, true);
stage.addEventListener('pointerdown', event => { if (event.isPrimary) pointer = { x: event.clientX, y: event.clientY }; });
stage.addEventListener('pointerup', event => {
  if (!pointer) return;
  const dx = event.clientX - pointer.x, dy = event.clientY - pointer.y;
  pointer = null;
  if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.3) {
    suppressClickUntil = performance.now() + 500;
    event.preventDefault();
    go(nextPage(page, dx < 0 ? 1 : -1, book.pages.length, single));
  }
});
stage.addEventListener('pointercancel', () => pointer = null);

reader.querySelector('.reader-zoom').addEventListener('click', event => {
  zoomTrigger = event.currentTarget;
  const gallery = zoom.querySelector('.zoom-images');
  gallery.replaceChildren();
  for (const index of visible()) {
    const figure = document.createElement('figure');
    const image = document.createElement('img');
    image.src = book.pages[index].full;
    image.alt = book.pages[index].alt;
    const caption = document.createElement('figcaption');
    caption.textContent = book.pages[index].alt;
    figure.append(caption, image);
    gallery.append(figure);
  }
  zoom.showModal();
  zoom.scrollTop = 0;
});
zoom.querySelector('.zoom-close').addEventListener('click', () => zoom.close());
zoom.addEventListener('close', () => zoomTrigger?.focus({ preventScroll: true }));
zoom.addEventListener('click', event => {
  const r = zoom.getBoundingClientRect();
  if (event.target === zoom && (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom)) zoom.close();
});
const fullscreen = reader.querySelector('.reader-fullscreen');
fullscreen.addEventListener('click', async () => {
  if (document.fullscreenElement) { await document.exitFullscreen(); return; }
  if (document.body.classList.contains('reader-expanded')) { document.body.classList.remove('reader-expanded'); fullscreen.textContent = 'На весь экран ↗'; return; }
  if (reader.requestFullscreen) {
    try { await reader.requestFullscreen(); return; } catch (_) { /* Use an in-page expansion where fullscreen is unavailable. */ }
  }
  document.body.classList.add('reader-expanded');
  fullscreen.textContent = 'Свернуть ↙';
});
document.addEventListener('fullscreenchange', () => fullscreen.textContent = document.fullscreenElement ? 'Свернуть ↙' : 'На весь экран ↗');
function resize() {
  if (busy) { resizePending = true; return; }
  single = mobile.matches;
  if (!single) page = firstPageOfSpread(spreadForPage(page, book.pages.length), book.pages.length);
  render();
}
mobile.addEventListener('change', resize);
busy = true;
syncControls();
preload(0).then(() => { busy = false; render(); }).catch(() => {
  busy = false;
  error.textContent = 'Обложка не загрузилась. Обновите страницу, чтобы повторить загрузку.';
  render();
});
