const imklivaData=JSON.parse(document.querySelector('#imkliva-data').textContent);
const viewer=document.querySelector('.imkliva-viewer');
const canvas=viewer.querySelector('.imkliva-canvas'),slideImage=viewer.querySelector('.imkliva-slide');
const select=viewer.querySelector('select'),counter=viewer.querySelector('.imkliva-counter'),loading=viewer.querySelector('.imkliva-loading');
const zoom=document.querySelector('.imkliva-zoom');
const stepButtons=[...viewer.querySelectorAll('[data-imkliva-step]')];
const zoomButtons=[...zoom.querySelectorAll('[data-imkliva-zoom-step]')];
let current=0,zoomTrigger,previousOverflow='',touchStart=null,swiped=false;
const pad=n=>String(n).padStart(2,'0');
function renderSlide(target){
 current=Math.max(0,Math.min(imklivaData.slides.length-1,target));
 const slide=imklivaData.slides[current],label=pad(current+1)+' / '+pad(imklivaData.slides.length);
 slideImage.src=slide.src;slideImage.alt='imkliva — слайд '+(current+1)+': '+slide.title;
 counter.textContent=label;select.value=String(current);
 viewer.setAttribute('aria-busy',String(!slideImage.complete));loading.textContent=slideImage.complete?'':'Загрузка слайда…';
 for(const button of stepButtons)button.disabled=Number(button.dataset.imklivaStep)<0?current===0:current===imklivaData.slides.length-1;
 for(const button of zoomButtons)button.disabled=Number(button.dataset.imklivaZoomStep)<0?current===0:current===imklivaData.slides.length-1;
 if(zoom.open){zoom.querySelector('img').src=slide.full;zoom.querySelector('img').alt=slideImage.alt;zoom.querySelector('h2').textContent='imkliva — '+label;zoom.querySelector('.imkliva-original').href=slide.full;}
 for(const next of [current-1,current+1])if(imklivaData.slides[next]){const preload=new Image();preload.src=imklivaData.slides[next].src;}
}
slideImage.addEventListener('load',()=>{viewer.setAttribute('aria-busy','false');loading.textContent='';});
slideImage.addEventListener('error',()=>{viewer.setAttribute('aria-busy','false');loading.textContent='Не удалось загрузить слайд. Можно открыть все слайды по ссылке ниже.';});
for(const button of stepButtons)button.addEventListener('click',()=>renderSlide(current+Number(button.dataset.imklivaStep)));
for(const button of zoomButtons)button.addEventListener('click',()=>renderSlide(current+Number(button.dataset.imklivaZoomStep)));
select.addEventListener('change',()=>renderSlide(Number(select.value)));
function keyboard(event){if(event.altKey||event.ctrlKey||event.metaKey||['SELECT','INPUT'].includes(event.target.tagName))return;let next;if(event.key==='ArrowRight')next=current+1;else if(event.key==='ArrowLeft')next=current-1;else if(event.key==='Home')next=0;else if(event.key==='End')next=imklivaData.slides.length-1;else return;event.preventDefault();renderSlide(next);}
viewer.addEventListener('keydown',keyboard);zoom.addEventListener('keydown',keyboard);
function openZoom(event){if(swiped)return;if(typeof zoom.showModal!=='function'){window.open(imklivaData.slides[current].full,'_blank','noopener');return;}zoomTrigger=event.currentTarget;previousOverflow=document.body.style.overflow;zoom.showModal();document.body.style.overflow='hidden';renderSlide(current);}
canvas.addEventListener('click',openZoom);viewer.querySelector('.imkliva-enlarge').addEventListener('click',openZoom);
zoom.querySelector('.imkliva-zoom-close').addEventListener('click',()=>zoom.close());
zoom.addEventListener('close',()=>{document.body.style.overflow=previousOverflow;zoomTrigger?.focus({preventScroll:true});});
zoom.addEventListener('click',event=>{const r=zoom.getBoundingClientRect();if(event.target===zoom&&(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom))zoom.close();});
canvas.addEventListener('touchstart',event=>{touchStart=event.touches.length===1?{x:event.touches[0].clientX,y:event.touches[0].clientY}:null;},{passive:true});
canvas.addEventListener('touchend',event=>{if(!touchStart)return;const dx=event.changedTouches[0].clientX-touchStart.x,dy=event.changedTouches[0].clientY-touchStart.y;touchStart=null;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.3){swiped=true;renderSlide(current+(dx<0?1:-1));setTimeout(()=>swiped=false,400);}},{passive:true});
canvas.addEventListener('touchcancel',()=>touchStart=null,{passive:true});
renderSlide(0);
