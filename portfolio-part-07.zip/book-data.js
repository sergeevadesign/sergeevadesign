export const book = {
  "title": "Скиапарелли: кутюр & сюрреализм",
  "width": 1719,
  "height": 2048,
  "pages": [
    {
      "src": "assets/schiaparelli/01.webp",
      "full": "assets/schiaparelli/01-full.jpg",
      "alt": "Передняя обложка книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/02.webp",
      "full": "assets/schiaparelli/02-full.jpg",
      "alt": "Страница 2 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/03.webp",
      "full": "assets/schiaparelli/03-full.jpg",
      "alt": "Страница 3 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/04.webp",
      "full": "assets/schiaparelli/04-full.jpg",
      "alt": "Страница 4 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/05.webp",
      "full": "assets/schiaparelli/05-full.jpg",
      "alt": "Страница 5 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/06.webp",
      "full": "assets/schiaparelli/06-full.jpg",
      "alt": "Страница 6 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/07.webp",
      "full": "assets/schiaparelli/07-full.jpg",
      "alt": "Страница 7 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/08.webp",
      "full": "assets/schiaparelli/08-full.jpg",
      "alt": "Страница 8 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/09.webp",
      "full": "assets/schiaparelli/09-full.jpg",
      "alt": "Страница 9 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/10.webp",
      "full": "assets/schiaparelli/10-full.jpg",
      "alt": "Страница 10 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/11.webp",
      "full": "assets/schiaparelli/11-full.jpg",
      "alt": "Страница 11 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/12.webp",
      "full": "assets/schiaparelli/12-full.jpg",
      "alt": "Страница 12 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/13.webp",
      "full": "assets/schiaparelli/13-full.jpg",
      "alt": "Страница 13 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/14.webp",
      "full": "assets/schiaparelli/14-full.jpg",
      "alt": "Страница 14 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/15.webp",
      "full": "assets/schiaparelli/15-full.jpg",
      "alt": "Страница 15 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/16.webp",
      "full": "assets/schiaparelli/16-full.jpg",
      "alt": "Страница 16 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/17.webp",
      "full": "assets/schiaparelli/17-full.jpg",
      "alt": "Страница 17 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/18.webp",
      "full": "assets/schiaparelli/18-full.jpg",
      "alt": "Страница 18 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/19.webp",
      "full": "assets/schiaparelli/19-full.jpg",
      "alt": "Страница 19 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/20.webp",
      "full": "assets/schiaparelli/20-full.jpg",
      "alt": "Страница 20 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/21.webp",
      "full": "assets/schiaparelli/21-full.jpg",
      "alt": "Страница 21 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/22.webp",
      "full": "assets/schiaparelli/22-full.jpg",
      "alt": "Страница 22 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/23.webp",
      "full": "assets/schiaparelli/23-full.jpg",
      "alt": "Страница 23 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/24.webp",
      "full": "assets/schiaparelli/24-full.jpg",
      "alt": "Страница 24 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/25.webp",
      "full": "assets/schiaparelli/25-full.jpg",
      "alt": "Страница 25 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/26.webp",
      "full": "assets/schiaparelli/26-full.jpg",
      "alt": "Страница 26 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/27.webp",
      "full": "assets/schiaparelli/27-full.jpg",
      "alt": "Страница 27 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/28.webp",
      "full": "assets/schiaparelli/28-full.jpg",
      "alt": "Страница 28 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/29.webp",
      "full": "assets/schiaparelli/29-full.jpg",
      "alt": "Страница 29 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/30.webp",
      "full": "assets/schiaparelli/30-full.jpg",
      "alt": "Страница 30 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/31.webp",
      "full": "assets/schiaparelli/31-full.jpg",
      "alt": "Страница 31 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/32.webp",
      "full": "assets/schiaparelli/32-full.jpg",
      "alt": "Страница 32 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/33.webp",
      "full": "assets/schiaparelli/33-full.jpg",
      "alt": "Страница 33 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/34.webp",
      "full": "assets/schiaparelli/34-full.jpg",
      "alt": "Страница 34 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/35.webp",
      "full": "assets/schiaparelli/35-full.jpg",
      "alt": "Страница 35 книги «Скиапарелли»"
    },
    {
      "src": "assets/schiaparelli/36.webp",
      "full": "assets/schiaparelli/36-full.jpg",
      "alt": "Задняя обложка книги «Скиапарелли»"
    }
  ]
};
