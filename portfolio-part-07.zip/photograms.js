const reduced = matchMedia('(prefers-reduced-motion: reduce)');

document.querySelectorAll('[data-photogram-carousel]').forEach(gallery => {
  const strip = gallery.querySelector('.photogram-strip');
  const cards = [...strip.querySelectorAll('.photogram-card')];
  const previous = gallery.querySelector('[data-slide="-1"]');
  const next = gallery.querySelector('[data-slide="1"]');
  const counter = gallery.querySelector('.photogram-counter');
  const dialog = gallery.querySelector('.photogram-viewer');
  const image = dialog.querySelector('.photogram-viewer-image');
  const title = dialog.querySelector('h2');
  const viewerPosition = dialog.querySelector('.photogram-viewer-position');
  const viewerError = dialog.querySelector('.photogram-viewer-error');
  const original = dialog.querySelector('.photogram-original');
  const viewerPrevious = dialog.querySelector('[data-view="-1"]');
  const viewerNext = dialog.querySelector('[data-view="1"]');
  let scheduled = false, active = 0, trigger, loadVersion = 0, previousOverflow;
  const behavior = () => reduced.matches ? 'auto' : 'smooth';

  function closestIndex() {
    let best = 0, distance = Infinity;
    cards.forEach((card, i) => {
      const delta = Math.abs(card.offsetLeft - strip.scrollLeft);
      if (delta < distance) { distance = delta; best = i; }
    });
    return best;
  }
  function visibleCount() {
    const gap = parseFloat(getComputedStyle(strip).columnGap) || 0;
    return Math.max(1, Math.floor((strip.clientWidth + gap + 1) / (cards[0].clientWidth + gap)));
  }
  function update() {
    const r = strip.getBoundingClientRect();
    const visible = cards.map((card, i) => ({ r: card.getBoundingClientRect(), i })).filter(({ r: c }) => Math.min(c.right, r.right) - Math.max(c.left, r.left) > Math.min(35, c.width * .15));
    if (visible.length) counter.textContent = `${String(visible[0].i + 1).padStart(2, '0')}–${String(visible.at(-1).i + 1).padStart(2, '0')} / ${cards.length}`;
    previous.disabled = strip.scrollLeft <= 2;
    next.disabled = strip.scrollLeft >= strip.scrollWidth - strip.clientWidth - 2;
    scheduled = false;
  }
  function schedule() {
    if (!scheduled) { scheduled = true; requestAnimationFrame(update); }
  }
  function slide(direction) {
    const index = Math.max(0, Math.min(cards.length - visibleCount(), closestIndex() + direction * visibleCount()));
    strip.scrollTo({ left: cards[index].offsetLeft, behavior: behavior() });
  }
  previous.addEventListener('click', () => slide(-1));
  next.addEventListener('click', () => slide(1));
  strip.addEventListener('scroll', schedule, { passive: true });
  if ('ResizeObserver' in window) new ResizeObserver(schedule).observe(strip);
  else window.addEventListener('resize', schedule);
  strip.addEventListener('keydown', event => {
    if (!['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const focused = cards.indexOf(document.activeElement);
    if (focused >= 0 || event.key === 'Home' || event.key === 'End') {
      const target = event.key === 'Home' ? 0 : event.key === 'End' ? cards.length - 1 : Math.max(0, Math.min(cards.length - 1, focused + (event.key === 'ArrowRight' ? 1 : -1)));
      cards[target].focus({ preventScroll: true });
      strip.scrollTo({ left: cards[target].offsetLeft, behavior: behavior() });
    } else slide(event.key === 'ArrowRight' ? 1 : -1);
  });
  function show(index) {
    active = Math.max(0, Math.min(cards.length - 1, index));
    const card = cards[active];
    const version = ++loadVersion;
    viewerError.textContent = '';
    image.onload = () => { if (version === loadVersion) image.removeAttribute('aria-busy'); };
    image.onerror = () => { if (version === loadVersion) { image.removeAttribute('aria-busy'); viewerError.textContent = 'Изображение не загрузилось. Откройте оригинал или повторите попытку.'; } };
    image.setAttribute('aria-busy', 'true');
    image.src = card.href;
    image.alt = card.querySelector('img').alt;
    title.textContent = card.dataset.label;
    original.href = card.href;
    viewerPosition.textContent = `${active + 1} / ${cards.length}`;
    viewerPrevious.disabled = active === 0;
    viewerNext.disabled = active === cards.length - 1;
    const neighbor = cards[active + 1];
    if (neighbor) { const preload = new Image(); preload.src = neighbor.href; }
  }
  cards.forEach((card, i) => card.addEventListener('click', event => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || typeof dialog.showModal !== 'function') return;
    event.preventDefault();
    trigger = card;
    show(i);
    previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialog.showModal();
  }));
  viewerPrevious.addEventListener('click', () => show(active - 1));
  viewerNext.addEventListener('click', () => show(active + 1));
  dialog.querySelector('.photogram-close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('close', () => { document.body.style.overflow = previousOverflow || ''; trigger?.focus({ preventScroll: true }); });
  dialog.addEventListener('click', event => {
    const r = dialog.getBoundingClientRect();
    if (event.target === dialog && (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom)) dialog.close();
  });
  dialog.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); show(active + (event.key === 'ArrowRight' ? 1 : -1)); }
  });
  gallery.querySelector('[data-carousel-controls]').hidden = false;
  update();
});
