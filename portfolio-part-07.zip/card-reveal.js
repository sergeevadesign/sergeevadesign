const card = document.querySelector('.business-card');
const image = card?.querySelector('.business-card-image');
const pixels = card?.querySelector('.card-pixels');
const motion = matchMedia('(prefers-reduced-motion: reduce)');

if (card && image && pixels && !motion.matches) {
  card.classList.add('is-revealing');
  const finish = () => {
    card.classList.remove('is-revealing', 'is-ready');
    pixels.remove();
  };
  const start = () => {
    if (motion.matches) { finish(); return; }
    card.classList.add('is-ready');
    window.setTimeout(finish, Number(pixels.dataset.revealEnd) || 1400);
  };
  if (image.complete && image.naturalWidth > 0) start();
  else {
    image.addEventListener('load', start, { once: true });
    image.addEventListener('error', finish, { once: true });
  }
  motion.addEventListener('change', event => { if (event.matches) finish(); }, { once: true });
}
