import { clampSpread, flipPlan, flipMode, coverPlan, coverFrame } from './fragment-state.mjs?v=3';
const reader = document.querySelector('.fragment-reader');
const stage = reader.querySelector('.fragment-stage');
const upper = stage.querySelector('.fragment-top img');
const lower = stage.querySelector('.fragment-bottom img');
const motion = stage.querySelector('.fragment-motion');
const status = reader.querySelector('.reader-status');
const error = reader.querySelector('.reader-error');
const slider = reader.querySelector('input');
const zoom = document.querySelector('#fragment-zoom');
const zoomButton = reader.querySelector('.reader-zoom');
const fullButton = reader.querySelector('.reader-fullscreen');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const cache = new Map();
let spreads = [], index = 0, busy = true, pointer, suppressClick = 0, activeAnimation;
function imageReady(src) {
  if (cache.has(src)) return cache.get(src);
  const promise = new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => { cache.delete(src); reject(new Error('Image failed')); };
    image.src = src;
  });
  cache.set(src, promise);
  return promise;
}
function prepare(at) {
  const spread = spreads[at];
  return spread ? Promise.all([spread.top, spread.bottom].filter(Boolean).map(imageReady)) : Promise.resolve();
}
function controls() {
  reader.setAttribute('aria-busy', String(busy));
  reader.querySelectorAll('[data-step]').forEach(button => {
    button.disabled = busy || !spreads.length || (Number(button.dataset.step) < 0 ? index === 0 : index === spreads.length - 1);
  });
  slider.disabled = busy || !spreads.length;
  zoomButton.disabled = busy || !spreads.length;
  fullButton.disabled = busy;
}
function render() {
  const spread = spreads[index];
  stage.classList.toggle('is-closed', spread.kind === 'cover');
  if (spread.top) upper.src = spread.top; else upper.removeAttribute('src');
  lower.src = spread.bottom;
  upper.alt = `${spread.topLabel}. Верхняя страница`;
  lower.alt = `${spread.bottomLabel}. Нижняя страница`;
  status.textContent = spread.label;
  slider.value = index + 1;
  slider.setAttribute('aria-valuetext', `${spread.label}, разворот ${index + 1} из ${spreads.length}`);
  reader.querySelector('.fragment-position').textContent = spread.kind === 'cover' ? spread.label : `Разворот ${index} из ${spreads.length - 2}`;
  reader.querySelector('.turn-next').textContent = index === 0 ? 'Открыть ↑' : index === spreads.length - 2 ? 'Закрыть ↓' : 'Листать ↑';
  reader.querySelector('.reader-controls [data-step="-1"]').textContent = index === 1 ? 'К обложке ↓' : index === spreads.length - 1 ? 'Открыть ↑' : '↓ Назад';
  stage.querySelector('.fragment-hit').setAttribute('aria-label', index === 0 ? 'Открыть обложку календаря' : 'Перелистнуть календарь вверх');
  reader.querySelector('.reader-hint').textContent = spread.kind === 'cover' ? (index === 0 ? 'Обложка. Нажмите «Открыть ↑» или проведите вверх, чтобы увидеть первый разворот.' : 'Задняя обложка. Нажмите «Открыть ↑», чтобы вернуться к последнему развороту.') : 'Две страницы разворота соединены пружиной в центре. Листайте вверх кнопкой или свайпом, вниз — вернуться.';
  controls();
  prepare(index + 1).catch(() => {});
  prepare(index - 1).catch(() => {});
}
function turn(target) {
  const plan = flipPlan(index, target);
  const leaf = document.createElement('div');
  leaf.className = 'fragment-leaf';
  const shades = [];
  for (const [side, spec] of [['front', plan.front], ['back', plan.back]]) {
    const face = document.createElement('div');
    face.className = `fragment-face ${side}`;
    const image = document.createElement('img');
    image.src = spreads[spec.index][spec.side];
    image.alt = '';
    const shade = document.createElement('div');
    shade.className = 'fragment-shade';
    shades.push(shade);
    face.append(image, shade);
    leaf.append(face);
  }
  leaf.style.transform = `rotateX(${plan.forward ? 0 : 180}deg)`;
  upper.src = spreads[plan.top].top;
  lower.src = spreads[plan.bottom].bottom;
  motion.append(leaf);
  return new Promise(resolve => {
    let start;
    function finish() {
      if (!leaf.isConnected) return;
      index = target;
      render();
      leaf.remove();
      activeAnimation = null;
      resolve();
    }
    activeAnimation = finish;
    function frame(now) {
      if (!leaf.isConnected) return;
      start ??= now;
      const t = Math.min(1, (now - start) / 1050);
      const eased = t * t * (3 - 2 * t);
      const p = plan.forward ? eased : 1 - eased;
      leaf.style.transform = `rotateX(${p * 180}deg)`;
      shades.forEach(shade => shade.style.opacity = Math.sin(p * Math.PI) * .045);
      if (t < 1) requestAnimationFrame(frame); else finish();
    }
    requestAnimationFrame(frame);
  });
}
function turnCover(target) {
  const plan = coverPlan(index, target, spreads);
  const leaf = document.createElement('div');
  leaf.className = 'fragment-leaf';
  const shades = [];
  for (const [side, src] of [['front', plan.front], ['back', plan.back]]) {
    const face = document.createElement('div');
    face.className = `fragment-face ${side}`;
    const image = document.createElement('img');
    image.src = src;
    image.alt = '';
    const shade = document.createElement('div');
    shade.className = 'fragment-shade';
    shades.push(shade);
    face.append(image, shade);
    leaf.append(face);
  }
  const setFrame = q => {
    const frame = coverFrame(q, stage.clientWidth);
    stage.style.height = `${frame.height}px`;
    stage.style.setProperty('--hinge', `${frame.hinge}px`);
    leaf.style.transform = `rotateX(${frame.angle}deg)`;
    shades.forEach(shade => shade.style.opacity = Math.sin(q * Math.PI) * .045);
  };
  setFrame(plan.opening ? 0 : 1);
  stage.classList.add('is-cover-turn');
  lower.src = plan.bottom;
  motion.append(leaf);
  return new Promise(resolve => {
    let start;
    function finish() {
      if (!leaf.isConnected) return;
      index = target;
      render();
      stage.style.removeProperty('height');
      stage.style.removeProperty('--hinge');
      stage.classList.remove('is-cover-turn');
      leaf.remove();
      activeAnimation = null;
      resolve();
    }
    activeAnimation = finish;
    function frame(now) {
      if (!leaf.isConnected) return;
      start ??= now;
      const t = Math.min(1, (now - start) / 1100);
      const eased = t * t * (3 - 2 * t);
      setFrame(plan.opening ? eased : 1 - eased);
      if (t < 1) requestAnimationFrame(frame); else finish();
    }
    requestAnimationFrame(frame);
  });
}
async function go(target, animate = true) {
  if (busy || !spreads.length) return;
  target = clampSpread(target, spreads.length);
  if (target === index) return;
  busy = true;
  error.textContent = '';
  controls();
  try {
    await Promise.all([prepare(index), prepare(target)]);
    if (animate && !reduced.matches && Math.abs(target - index) === 1) {
      if (flipMode(index, target, spreads) === 'cover') await turnCover(target);
      else await turn(target);
    }
    else { index = target; render(); }
  } catch (_) { error.textContent = 'Разворот не загрузился. Попробуйте ещё раз.'; }
  finally { busy = false; render(); }
}
reader.querySelectorAll('[data-step]').forEach(button => button.addEventListener('click', () => go(index + Number(button.dataset.step))));
slider.addEventListener('change', () => go(Number(slider.value) - 1, false));
stage.addEventListener('click', event => {
  if (performance.now() < suppressClick) { event.preventDefault(); event.stopImmediatePropagation(); }
}, true);
stage.addEventListener('pointerdown', event => {
  if (!event.isPrimary || busy) return;
  pointer = { id: event.pointerId, x: event.clientX, y: event.clientY };
});
stage.addEventListener('pointerup', event => {
  if (!pointer || pointer.id !== event.pointerId) return;
  const dx = event.clientX - pointer.x, dy = event.clientY - pointer.y;
  pointer = null;
  if (Math.abs(dy) > 35 && Math.abs(dy) > Math.abs(dx) * 1.2) {
    event.preventDefault(); suppressClick = performance.now() + 500;
    go(index + (dy < 0 ? 1 : -1));
  }
});
stage.addEventListener('pointercancel', () => pointer = null);
window.addEventListener('pointerup', () => pointer = null);
document.addEventListener('keydown', event => {
  if (zoom.open || ['INPUT','TEXTAREA','SELECT','BUTTON','A'].includes(event.target.tagName) || event.ctrlKey || event.metaKey || event.altKey) return;
  if (['ArrowUp','ArrowRight','ArrowDown','ArrowLeft'].includes(event.key)) {
    event.preventDefault(); go(index + (['ArrowUp','ArrowRight'].includes(event.key) ? 1 : -1));
  }
  if (event.key === 'Home') { event.preventDefault(); go(0, false); }
  if (event.key === 'End') { event.preventDefault(); go(spreads.length - 1, false); }
  if (event.key === 'Escape') { document.body.classList.remove('reader-expanded'); fullButton.textContent = 'На весь экран ↗'; }
});
zoomButton.addEventListener('click', () => {
  const spread = spreads[index];
  zoom.querySelector('h2').textContent = spread.label;
  const images = zoom.querySelectorAll('.fragment-zoom-spread img');
  images[0].hidden = !spread.topFull;
  if (spread.topFull) images[0].src = spread.topFull; else images[0].removeAttribute('src');
  images[1].src = spread.bottomFull;
  images[0].alt = `${spread.topLabel}. Верхняя страница`;
  images[1].alt = `${spread.bottomLabel}. Нижняя страница`;
  zoom.showModal(); zoom.scrollTop = 0;
});
zoom.querySelector('.zoom-close').addEventListener('click', () => zoom.close());
zoom.addEventListener('close', () => zoomButton.focus({preventScroll:true}));
zoom.addEventListener('click', event => {
  const r = zoom.getBoundingClientRect();
  if (event.target === zoom && (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom)) zoom.close();
});
fullButton.addEventListener('click', async () => {
  if (document.fullscreenElement) { await document.exitFullscreen(); return; }
  if (document.body.classList.contains('reader-expanded')) { document.body.classList.remove('reader-expanded'); fullButton.textContent = 'На весь экран ↗'; return; }
  if (reader.requestFullscreen) { try { await reader.requestFullscreen(); return; } catch (_) {} }
  document.body.classList.add('reader-expanded'); fullButton.textContent = 'Свернуть ↙';
});
document.addEventListener('fullscreenchange', () => fullButton.textContent = document.fullscreenElement ? 'Свернуть ↙' : 'На весь экран ↗');
reduced.addEventListener('change', () => { if (reduced.matches) activeAnimation?.(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) activeAnimation?.(); });
controls();
try {
  const response = await fetch('fragment-data.json?v=3');
  if (!response.ok) throw new Error('Data failed');
  ({spreads} = await response.json());
  slider.max = spreads.length;
  await prepare(0);
  busy = false; render();
} catch (_) {
  busy = false; controls();
  error.append('Не удалось загрузить календарь. ', Object.assign(document.createElement('a'), {href:'fragment-pages.html',textContent:'Посмотреть все развороты →'}));
}
