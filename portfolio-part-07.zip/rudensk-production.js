const reader=document.querySelector('[data-rudensk-reader]');
if(reader){
 const stage=reader.querySelector('.rudensk-book-stage');
 const toggle=reader.querySelector('.rudensk-toggle');
 const hit=reader.querySelector('.rudensk-book-hit');
 const status=reader.querySelector('.rudensk-status');
 const zoom=document.querySelector('.rudensk-zoom');
 let opened=false,zoomOverflow='',zoomTrigger;
 function setOpen(next){opened=next;stage.classList.toggle('is-open',opened);stage.querySelector('.front').setAttribute('aria-hidden',String(opened));stage.querySelector('.back').setAttribute('aria-hidden',String(!opened));stage.querySelector('.rudensk-book-under').setAttribute('aria-hidden',String(!opened));stage.setAttribute('aria-label',opened?'Разворот производственного календаря':'Обложка производственного календаря');toggle.textContent=opened?'← Закрыть обложку':'Открыть календарь →';status.textContent=opened?'Разворот':'Обложка';for(const el of [toggle,hit])el.setAttribute('aria-expanded',String(opened));hit.setAttribute('aria-label',opened?'Закрыть обложку':'Открыть обложку');}
 setOpen(false);
 toggle.addEventListener('click',()=>setOpen(!opened));hit.addEventListener('click',()=>setOpen(!opened));
 stage.addEventListener('keydown',event=>{if(event.altKey||event.ctrlKey||event.metaKey)return;if(event.key==='ArrowRight'){event.preventDefault();setOpen(true);}if(event.key==='ArrowLeft'){event.preventDefault();setOpen(false);}});
 let startX=null,startY=null;
 stage.addEventListener('touchstart',event=>{if(event.touches.length===1){startX=event.touches[0].clientX;startY=event.touches[0].clientY;}},{passive:true});
 stage.addEventListener('touchend',event=>{if(startX===null)return;const dx=event.changedTouches[0].clientX-startX,dy=event.changedTouches[0].clientY-startY;startX=null;if(Math.abs(dx)>50&&Math.abs(dx)>Math.abs(dy)*1.3){setOpen(dx<0);hit.dataset.swiped='true';setTimeout(()=>delete hit.dataset.swiped,400);}},{passive:true});
 hit.addEventListener('click',event=>{if(hit.dataset.swiped){event.stopImmediatePropagation();setOpen(opened);}},true);
 reader.querySelector('.rudensk-enlarge').addEventListener('click',event=>{const id=opened?'production-spread':'production-cover';zoom.querySelector('img').src='assets/rudensk/'+id+'-original.jpg';zoom.querySelector('img').alt=opened?'Полный разворот производственного календаря':'Обложка производственного календаря';zoom.querySelector('h2').textContent=opened?'Производственный календарь — разворот':'Производственный календарь — обложка';zoom.querySelector('a').href='assets/rudensk/'+id+'-original.jpg';zoomTrigger=event.currentTarget;zoomOverflow=document.body.style.overflow;zoom.showModal();document.body.style.overflow='hidden';});
 zoom.querySelector('button').addEventListener('click',()=>zoom.close());zoom.addEventListener('close',()=>{document.body.style.overflow=zoomOverflow;zoomTrigger?.focus({preventScroll:true});});
 zoom.addEventListener('click',event=>{const r=zoom.getBoundingClientRect();if(event.target===zoom&&(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom))zoom.close();});
}
