// Images are in reading order: cover, even/odd interior pages, back cover.
export function spreadForPage(page, total) {
  return Math.max(0, Math.min(total / 2, Math.floor((page + 1) / 2)));
}
export function pagesForSpread(spread, total) {
  return [spread > 0 ? spread * 2 - 1 : null, spread < total / 2 ? spread * 2 : null];
}
export function firstPageOfSpread(spread, total) {
  return pagesForSpread(spread, total).find(page => page !== null);
}
export function nextPage(page, direction, total, single) {
  if (single) return Math.max(0, Math.min(total - 1, page + direction));
  const spread = Math.max(0, Math.min(total / 2, spreadForPage(page, total) + direction));
  return firstPageOfSpread(spread, total);
}
