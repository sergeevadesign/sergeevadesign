const dialog = document.querySelector('.identity-lightbox');
const image = dialog.querySelector('.identity-lightbox-image');
const title = dialog.querySelector('h2');
const original = dialog.querySelector('.identity-lightbox-original');
let trigger, overflow;
document.querySelectorAll('[data-identity-zoom]').forEach(link => link.addEventListener('click', event => {
  if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey || event.button !== 0 || !dialog.showModal) return;
  event.preventDefault();
  trigger = link;
  image.src = link.href;
  image.alt = link.dataset.caption;
  title.textContent = link.dataset.caption;
  original.href = link.href;
  overflow = document.body.style.overflow;
  dialog.showModal();
  document.body.style.overflow = 'hidden';
}));
dialog.querySelector('.identity-lightbox-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('close', () => {document.body.style.overflow = overflow; trigger?.focus({preventScroll:true});});
dialog.addEventListener('click', event => {
  const r = dialog.getBoundingClientRect();
  if (event.target === dialog && (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom)) dialog.close();
});
