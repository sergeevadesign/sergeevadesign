import { calendar } from './calendar-data.js?v=2';
import { clampLeaf, calendarStack, calendarCurl } from './calendar-state.mjs';

const reader = document.querySelector('.calendar-reader');
const stage = reader.querySelector('.calendar-stage');
const surface = reader.querySelector('.calendar-surface');
const stack = reader.querySelector('.calendar-stack');
const clip = reader.querySelector('.calendar-clip');
const status = reader.querySelector('.reader-status');
const type = reader.querySelector('.calendar-type');
const error = reader.querySelector('.reader-error');
const slider = reader.querySelector('input[type="range"]');
const zoom = document.querySelector('#calendar-zoom');
const fullscreen = reader.querySelector('.reader-fullscreen');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const cache = new Map();
let index = 0, busy = true, suppressClickUntil = 0, pointer, zoomTrigger;

function preload(i) {
  if (i < 0 || i >= calendar.pages.length) return Promise.resolve();
  if (cache.has(i)) return cache.get(i);
  const promise = new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = resolve;
    image.onerror = () => { cache.delete(i); reject(new Error('image')); };
    image.src = calendar.pages[i].src;
  });
  cache.set(i, promise);
  return promise;
}
function prepare(i) {
  return Promise.all(calendarStack(i, calendar.pages).map(preload));
}
function paper(i, full = false) {
  const page = calendar.pages[i];
  const layer = document.createElement('div');
  layer.className = 'calendar-paper' + (page.type === 'vellum' ? ' vellum' : '');
  const image = document.createElement('img');
  image.src = full ? page.full : page.src;
  image.alt = full ? page.alt : '';
  image.draggable = false;
  layer.append(image);
  return layer;
}
function drawStack(at, target = stack, full = false) {
  target.replaceChildren();
  calendarStack(at, calendar.pages).reverse().forEach(i => target.append(paper(i, full)));
}
function controls() {
  reader.querySelectorAll('[data-step]').forEach(button => {
    const direction = Number(button.dataset.step);
    button.disabled = busy || (direction < 0 ? index === 0 : index === calendar.pages.length - 1);
  });
  slider.disabled = busy;
  fullscreen.disabled = busy;
  reader.querySelector('.reader-zoom').disabled = busy;
  reader.setAttribute('aria-busy', String(busy));
}
function render() {
  drawStack(index);
  status.textContent = calendar.pages[index].label;
  type.textContent = calendar.pages[index].type === 'vellum' ? 'Калька · стихотворение поверх следующего листа' : index === 0 ? 'Календарь-каталог парфюма · 2026' : index === calendar.pages.length - 1 ? 'Задняя обложка' : 'Печатный лист';
  slider.value = index + 1;
  slider.setAttribute('aria-valuetext', `Лист ${index + 1}: ${calendar.pages[index].label}`);
  reader.querySelector('.calendar-position').textContent = `Лист ${index + 1} из ${calendar.pages.length}`;
  controls();
  if (index + 1 < calendar.pages.length) prepare(index + 1).catch(() => {});
  if (index > 0) prepare(index - 1).catch(() => {});
}

function turn(target) {
  const forward = target > index;
  const leaf = forward ? index : target;
  const page = calendar.pages[leaf];
  const width = surface.clientWidth, height = surface.clientHeight, count = 20, step = height / count;
  const layer = document.createElement('div');
  layer.className = 'calendar-turn-layer';
  // Explicit pixel placement makes the hinge stay at the spring while the page bends.
  layer.style.top = '40px';
  layer.style.left = `${width * .16}px`;
  layer.style.width = `${width}px`;
  layer.style.height = `${height}px`;
  const strips = [];
  for (let i = 0; i < count; i++) {
    const strip = document.createElement('div');
    strip.className = 'calendar-strip';
    strip.style.height = `${step + (page.type === 'vellum' ? .005 : .35)}px`;
    const shades = [];
    for (let side = 0; side < 2; side++) {
      const face = document.createElement('div');
      face.className = 'calendar-strip-face' + (side ? ' back' : '') + (page.type === 'vellum' ? ' vellum' : '');
      if (!side || page.type === 'vellum') {
        const ink = document.createElement('div');
        ink.className = 'calendar-strip-ink';
        ink.style.backgroundImage = `url("${page.src}")`;
        ink.style.backgroundSize = `${width}px ${height}px`;
        ink.style.backgroundPosition = `0 ${-i * step}px`;
        face.append(ink);
      }
      const shade = document.createElement('div');
      shade.className = 'calendar-strip-shade';
      face.append(shade);
      shades.push(shade);
      strip.append(face);
    }
    strips.push({ strip, shades });
    layer.append(strip);
  }
  drawStack(forward ? target : index);
  clip.append(layer);
  return new Promise(resolve => {
    let start;
    function frame(now) {
      start ??= now;
      const t = Math.min(1, (now - start) / 1000);
      const eased = t * t * (3 - 2 * t);
      const p = forward ? eased : 1 - eased;
      const geometry = calendarCurl(p, height, count);
      strips.forEach(({ strip, shades }, i) => {
        const { y, z, angle } = geometry[i];
        strip.style.transform = `translate3d(0,${y}px,${z}px) rotateX(${angle}rad)`;
        shades.forEach(shade => shade.style.opacity = Math.sin(Math.PI * p) * .025);
      });
      layer.style.opacity = p <= .9 ? 1 : Math.max(0, 1 - (p - .9) * 10);
      if (t < 1) requestAnimationFrame(frame);
      else { index = target; render(); layer.remove(); resolve(); }
    }
    requestAnimationFrame(frame);
  });
}
async function go(target, animated = true) {
  target = clampLeaf(target, calendar.pages.length);
  if (busy || target === index) return;
  busy = true;
  error.textContent = '';
  controls();
  try {
    await Promise.all([prepare(index), prepare(target)]);
    if (animated && !reduced.matches && Math.abs(target - index) === 1) await turn(target);
    else { index = target; render(); }
  } catch (_) {
    error.textContent = 'Лист не загрузился. Проверьте соединение и попробуйте ещё раз.';
  } finally { busy = false; render(); }
}
reader.querySelectorAll('[data-step]').forEach(button => button.addEventListener('click', () => go(index + Number(button.dataset.step))));
slider.max = calendar.pages.length;
slider.addEventListener('change', () => go(Number(slider.value) - 1, false));
stage.addEventListener('click', event => {
  if (performance.now() < suppressClickUntil) { event.preventDefault(); event.stopImmediatePropagation(); }
}, true);
stage.addEventListener('pointerdown', event => { if (event.isPrimary) pointer = { x: event.clientX, y: event.clientY }; });
stage.addEventListener('pointerup', event => {
  if (!pointer) return;
  const dx = event.clientX - pointer.x, dy = event.clientY - pointer.y;
  pointer = null;
  if (Math.abs(dy) > 40 && Math.abs(dy) > Math.abs(dx) * 1.3) {
    event.preventDefault();
    suppressClickUntil = performance.now() + 500;
    go(index + (dy < 0 ? 1 : -1));
  }
});
stage.addEventListener('pointercancel', () => pointer = null);
document.addEventListener('keydown', event => {
  if (zoom.open || ['INPUT', 'TEXTAREA', 'SELECT'].includes(event.target.tagName)) return;
  if (['ArrowUp', 'ArrowRight', 'ArrowDown', 'ArrowLeft'].includes(event.key)) {
    event.preventDefault();
    go(index + (['ArrowUp', 'ArrowRight'].includes(event.key) ? 1 : -1));
  }
  if (event.key === 'Home') { event.preventDefault(); go(0, false); }
  if (event.key === 'End') { event.preventDefault(); go(calendar.pages.length - 1, false); }
  if (event.key === 'Escape') { document.body.classList.remove('reader-expanded'); fullscreen.textContent = 'На весь экран ↗'; }
});
reader.querySelector('.reader-zoom').addEventListener('click', event => {
  zoomTrigger = event.currentTarget;
  drawStack(index, zoom.querySelector('.calendar-zoom-page'), true);
  zoom.querySelector('h2').textContent = calendar.pages[index].label;
  zoom.showModal();
  zoom.scrollTop = 0;
});
zoom.querySelector('.zoom-close').addEventListener('click', () => zoom.close());
zoom.addEventListener('close', () => zoomTrigger?.focus({ preventScroll: true }));
zoom.addEventListener('click', event => {
  const r = zoom.getBoundingClientRect();
  if (event.target === zoom && (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom)) zoom.close();
});
fullscreen.addEventListener('click', async () => {
  if (document.fullscreenElement) { await document.exitFullscreen(); return; }
  if (document.body.classList.contains('reader-expanded')) { document.body.classList.remove('reader-expanded'); fullscreen.textContent = 'На весь экран ↗'; return; }
  if (reader.requestFullscreen) { try { await reader.requestFullscreen(); return; } catch (_) {} }
  document.body.classList.add('reader-expanded');
  fullscreen.textContent = 'Свернуть ↙';
});
document.addEventListener('fullscreenchange', () => fullscreen.textContent = document.fullscreenElement ? 'Свернуть ↙' : 'На весь экран ↗');
controls();
prepare(0).then(() => { busy = false; render(); }).catch(() => { busy = false; error.textContent = 'Не удалось загрузить календарь. Обновите страницу.'; render(); });
