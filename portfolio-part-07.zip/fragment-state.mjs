export const clampSpread = (index, total) => Math.max(0, Math.min(total - 1, index));
// One physical leaf connects the bottom of one spread to the top of the next.
export function flipPlan(from, to) {
  if (Math.abs(to - from) !== 1) throw new RangeError('Adjacent spreads required');
  const forward = to > from;
  return { forward, top: forward ? from : to, bottom: forward ? to : from,
    front: { index: forward ? from : to, side: 'bottom' },
    back: { index: forward ? to : from, side: 'top' } };
}

export function flipMode(from, to, states) {
  return states[from].kind === 'cover' || states[to].kind === 'cover' ? 'cover' : 'leaf';
}

// The closed cover is the front face; the first/last upper page is its reverse.
export function coverPlan(from, to, states) {
  if (Math.abs(to - from) !== 1 || flipMode(from, to, states) !== 'cover') throw new RangeError('Adjacent cover and spread required');
  const opening = states[from].kind === 'cover';
  const cover = states[opening ? from : to];
  const spread = states[opening ? to : from];
  return { opening, front: cover.bottom, back: spread.top, bottom: spread.bottom };
}
export function coverFrame(openness, width) {
  const q = Math.max(0, Math.min(1, openness));
  return {height: width * (1 + q), hinge: width * q, angle: 180 * q};
}
