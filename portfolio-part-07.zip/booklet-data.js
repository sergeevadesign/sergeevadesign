export const book = {
  "title": "Вяртанне",
  "kind": "Буклет",
  "width": 2048,
  "height": 2048,
  "pages": [
    {
      "sourceNumber": 17,
      "src": "assets/viartanne/01.webp",
      "full": "assets/viartanne/01-full.jpg",
      "alt": "Передняя обложка буклета «Вяртанне»"
    },
    {
      "sourceNumber": 18,
      "src": "assets/viartanne/02.webp",
      "full": "assets/viartanne/02-full.jpg",
      "alt": "Страница 2 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 19,
      "src": "assets/viartanne/03.webp",
      "full": "assets/viartanne/03-full.jpg",
      "alt": "Страница 3 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 20,
      "src": "assets/viartanne/04.webp",
      "full": "assets/viartanne/04-full.jpg",
      "alt": "Страница 4 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 21,
      "src": "assets/viartanne/05.webp",
      "full": "assets/viartanne/05-full.jpg",
      "alt": "Страница 5 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 22,
      "src": "assets/viartanne/06.webp",
      "full": "assets/viartanne/06-full.jpg",
      "alt": "Страница 6 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 23,
      "src": "assets/viartanne/07.webp",
      "full": "assets/viartanne/07-full.jpg",
      "alt": "Страница 7 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 24,
      "src": "assets/viartanne/08.webp",
      "full": "assets/viartanne/08-full.jpg",
      "alt": "Страница 8 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 25,
      "src": "assets/viartanne/09.webp",
      "full": "assets/viartanne/09-full.jpg",
      "alt": "Страница 9 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 26,
      "src": "assets/viartanne/10.webp",
      "full": "assets/viartanne/10-full.jpg",
      "alt": "Страница 10 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 27,
      "src": "assets/viartanne/11.webp",
      "full": "assets/viartanne/11-full.jpg",
      "alt": "Страница 11 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 28,
      "src": "assets/viartanne/12.webp",
      "full": "assets/viartanne/12-full.jpg",
      "alt": "Страница 12 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 29,
      "src": "assets/viartanne/13.webp",
      "full": "assets/viartanne/13-full.jpg",
      "alt": "Страница 13 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 30,
      "src": "assets/viartanne/14.webp",
      "full": "assets/viartanne/14-full.jpg",
      "alt": "Страница 14 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 31,
      "src": "assets/viartanne/15.webp",
      "full": "assets/viartanne/15-full.jpg",
      "alt": "Страница 15 буклета «Вяртанне»"
    },
    {
      "sourceNumber": 32,
      "src": "assets/viartanne/16.webp",
      "full": "assets/viartanne/16-full.jpg",
      "alt": "Задняя обложка буклета «Вяртанне»"
    }
  ]
};
