const diplomaDialog=document.querySelector('#award-diploma-dialog');
const diplomaTrigger=document.querySelector('.award-diploma-open');
if(diplomaDialog&&diplomaTrigger&&typeof diplomaDialog.showModal==='function'){
 let previousOverflow='';
 diplomaTrigger.addEventListener('click',event=>{
  event.preventDefault();previousOverflow=document.body.style.overflow;
  diplomaDialog.showModal();document.body.style.overflow='hidden';
 });
 diplomaDialog.querySelector('.award-diploma-close').addEventListener('click',()=>diplomaDialog.close());
 diplomaDialog.addEventListener('click',event=>{
  if(event.target!==diplomaDialog)return;
  const rect=diplomaDialog.getBoundingClientRect();
  if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)diplomaDialog.close();
 });
 diplomaDialog.addEventListener('close',()=>{
  document.body.style.overflow=previousOverflow;diplomaTrigger.focus({preventScroll:true});
 });
}
